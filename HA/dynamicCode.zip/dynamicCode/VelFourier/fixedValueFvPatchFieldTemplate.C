/*---------------------------------------------------------------------------*  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     | Website:  https://openfoam.org
    \\  /    A nd           | Copyright (C) YEAR OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

\*---------------------------------------------------------------------------*/

#include "fixedValueFvPatchFieldTemplate.H"
#include "addToRunTimeSelectionTable.H"
#include "fvPatchFieldMapper.H"
#include "volFields.H"
#include "surfaceFields.H"
#include "unitConversion.H"
//{{{ begin codeInclude

//}}} end codeInclude


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

namespace Foam
{

// * * * * * * * * * * * * * * * Local Functions * * * * * * * * * * * * * * //

//{{{ begin localCode

//}}} end localCode


// * * * * * * * * * * * * * * * Global Functions  * * * * * * * * * * * * * //

extern "C"
{
    // dynamicCode:
    // SHA1 = 77ee232b40521d352eae2debecdc29f2e482de99
    //
    // unique function name that can be checked if the correct library version
    // has been loaded
    void VelFourier_77ee232b40521d352eae2debecdc29f2e482de99(bool load)
    {
        if (load)
        {
            // code that can be explicitly executed after loading
        }
        else
        {
            // code that can be explicitly executed before unloading
        }
    }
}

// * * * * * * * * * * * * * * Static Data Members * * * * * * * * * * * * * //

makeRemovablePatchTypeField
(
    fvPatchVectorField,
    VelFourierFixedValueFvPatchVectorField
);


const char* const VelFourierFixedValueFvPatchVectorField::SHA1sum =
    "77ee232b40521d352eae2debecdc29f2e482de99";


// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

VelFourierFixedValueFvPatchVectorField::
VelFourierFixedValueFvPatchVectorField
(
    const fvPatch& p,
    const DimensionedField<vector, volMesh>& iF
)
:
    fixedValueFvPatchField<vector>(p, iF)
{
    if (false)
    {
        Info<<"construct VelFourier sha1: 77ee232b40521d352eae2debecdc29f2e482de99"
            " from patch/DimensionedField\n";
    }
}


VelFourierFixedValueFvPatchVectorField::
VelFourierFixedValueFvPatchVectorField
(
    const VelFourierFixedValueFvPatchVectorField& ptf,
    const fvPatch& p,
    const DimensionedField<vector, volMesh>& iF,
    const fvPatchFieldMapper& mapper
)
:
    fixedValueFvPatchField<vector>(ptf, p, iF, mapper)
{
    if (false)
    {
        Info<<"construct VelFourier sha1: 77ee232b40521d352eae2debecdc29f2e482de99"
            " from patch/DimensionedField/mapper\n";
    }
}


VelFourierFixedValueFvPatchVectorField::
VelFourierFixedValueFvPatchVectorField
(
    const fvPatch& p,
    const DimensionedField<vector, volMesh>& iF,
    const dictionary& dict
)
:
    fixedValueFvPatchField<vector>(p, iF, dict)
{
    if (false)
    {
        Info<<"construct VelFourier sha1: 77ee232b40521d352eae2debecdc29f2e482de99"
            " from patch/dictionary\n";
    }
}


VelFourierFixedValueFvPatchVectorField::
VelFourierFixedValueFvPatchVectorField
(
    const VelFourierFixedValueFvPatchVectorField& ptf
)
:
    fixedValueFvPatchField<vector>(ptf)
{
    if (false)
    {
        Info<<"construct VelFourier sha1: 77ee232b40521d352eae2debecdc29f2e482de99"
            " as copy\n";
    }
}


VelFourierFixedValueFvPatchVectorField::
VelFourierFixedValueFvPatchVectorField
(
    const VelFourierFixedValueFvPatchVectorField& ptf,
    const DimensionedField<vector, volMesh>& iF
)
:
    fixedValueFvPatchField<vector>(ptf, iF)
{
    if (false)
    {
        Info<<"construct VelFourier sha1: 77ee232b40521d352eae2debecdc29f2e482de99 "
            "as copy/DimensionedField\n";
    }
}


// * * * * * * * * * * * * * * * * Destructor  * * * * * * * * * * * * * * * //

VelFourierFixedValueFvPatchVectorField::
~VelFourierFixedValueFvPatchVectorField()
{
    if (false)
    {
        Info<<"destroy VelFourier sha1: 77ee232b40521d352eae2debecdc29f2e482de99\n";
    }
}


// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

void VelFourierFixedValueFvPatchVectorField::updateCoeffs()
{
    if (this->updated())
    {
        return;
    }

    if (false)
    {
        Info<<"updateCoeffs VelFourier sha1: 77ee232b40521d352eae2debecdc29f2e482de99\n";
    }

//{{{ begin code
    #line 131 "/home/simona/OpenFOAM/run/AortaSana/0/U/boundaryField/Inlet"
const fvPatch& boundaryPatch = patch();
                         const vectorField& Cf = boundaryPatch.Cf();
                         vectorField& field = *this;
                         const scalar &t = this ->db().time().value();     //lettura del tempo
                         const scalar a0=0.1152;
                         const scalar a1=0.06941;
                         const scalar b1=0.1772;
                         const scalar a2=-0.112;
                         const scalar b2=0.07215;
                         const scalar a3=-0.04831;
                         const scalar b3=-0.03095;
                         const scalar a4=-0.01316;
                         const scalar b4=-0.004442;
                         const scalar a5=-0.01729;
                         const scalar b5=-0.03011;
                         const scalar a6=0.01427;
                         const scalar b6=-0.005475;
                         const scalar a7=-0.0022805;
                         const scalar b7=-0.001794;
                         const scalar a8=0.006115;
                         const scalar b8=-0.0003022;
                         const scalar w=6.541;
                         forAll(Cf, faceI)
                         {
                           field[faceI]=vector(0, 0, a0+a1*cos(t*w)+b1*sin(t*w)+a2*cos(2*t*w)+b2*sin(2*t*w)+a3*cos(3*t*w)+b3*sin(3*t*w)+a4*cos(4*t*w)+b4*sin(4*t*w)+a5*cos(5*t*w)+b5*sin(5*t*w)+a6*cos(6*t*w)+b6*sin(6*t*w)+a7*cos(7*t*w)+b7*sin(7*t*w)+a8*cos(8*t*w)+b8*sin(8*t*w));
                                          
                         }
//}}} end code

    this->fixedValueFvPatchField<vector>::updateCoeffs();
}


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

} // End namespace Foam

// ************************************************************************* //

